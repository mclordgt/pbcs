$(function() {

	$('[rel="tooltip"]').tooltip();

});