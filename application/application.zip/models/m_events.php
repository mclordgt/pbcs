<?php
class M_events extends CI_Model{

	public function __construct(){

		parent::__construct();

	}

}