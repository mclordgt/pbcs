        </div><!-- #wrap -->

		<?php script_parser($scripts); ?>

    </body>
</html>