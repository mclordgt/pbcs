<?php $this->load->view('default/planning-header',$headerData); ?>

	<?php $this->load->view('templates/'.$pageView,$pageData); ?>
	
<?php $this->load->view('default/planning-footer',$footerData); ?>